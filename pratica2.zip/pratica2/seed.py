from models import Autor, Livro


def popular_banco(session):
    autor1 = Autor(nome="Julia Quinn", pais="Estados Unidos")
    autor2 = Autor(nome="Freida McFadden", pais="Estados Unidos")
    autor3 = Autor(nome="Jenny Han", pais="Estados Unidos")

    session.add_all([autor1, autor2, autor3])
    session.flush()

    
    livros = [
    
        Livro(
            titulo="O Duque e eu",
            ano=2000,
            autor_id=autor1.id,
            disponivel=True,
        ),
        Livro(
            titulo="O Visconde Que Me Amava",
            ano=2000,
            autor_id=autor1.id,
            disponivel=False,
        ),
        Livro(
            titulo="Para Sir Phillip, com Amor",
            ano=2003,
            autor_id=autor1.id,
            disponivel=True,
        ),
      
        Livro(
            titulo="A Empregada",
            ano=2022,
            autor_id=autor2.id,
            disponivel=True,
        ),
        Livro(
            titulo="Nunca Mintaa",
            ano=2022,
            autor_id=autor2.id,
            disponivel=False,
        ),

        Livro(
            titulo="Para todos os caras que já amei",
            ano=2014,
            autor_id=autor3.id,
            disponivel=True,
        ),
    ]

    session.add_all(livros)
    session.commit()