from sqlalchemy import select

from models import Livro


def emprestar_livro(session, titulo):
    stmt = select(Livro).where(Livro.titulo.icontains(titulo))
    livro = session.scalars(stmt).first()

    if not livro:
        print(f"Livro '{titulo}' não foi encontrado.")
        return

    if not livro.disponivel:
        print(f"O livro '{livro.titulo}' já está indisponível para empréstimo.")
        return

    livro.disponivel = False
    session.commit()
    print(f"Livro '{livro.titulo}' emprestado com sucesso!")


def devolver_livro(session, titulo):
    stmt = select(Livro).where(Livro.titulo.icontains(titulo))
    livro = session.scalars(stmt).first()

    if not livro:
        print(f"Livro '{titulo}' não foi encontrado.")
        return

    if livro.disponivel:
        print(f"O livro '{livro.titulo}' já consta como disponível no sistema.")
        return

    livro.disponivel = True
    session.commit()
    print(f"Livro '{livro.titulo}' devolvido com sucesso!")