from sqlalchemy import select

from models import Autor, Livro


def listar_livros(session):
  
    stmt = select(Livro)
    livros = session.scalars(stmt).all()

    for livro in livros:
        status = "Disponível" if livro.disponivel else "Indisponível"
        print(f"Livro: {livro.titulo} | Autor: {livro.autor.nome} | Status: {status}")

    return livros


def listar_livros_disponiveis(session):
    stmt = select(Livro).where(Livro.disponivel == True)
    livros_disponiveis = session.scalars(stmt).all()

    for livro in livros_disponiveis:
        print(f"Livro: {livro.titulo} | Autor: {livro.autor.nome}")

    return livros_disponiveis


def buscar_livros_por_titulo(session, trecho):
    stmt = select(Livro).where(Livro.titulo.icontains(trecho))
    livros = session.scalars(stmt).all()

    for livro in livros:
        status = "Disponível" if livro.disponivel else "Indisponível"
        print(f"Livro: {livro.titulo} | Autor: {livro.autor.nome} | Status: {status}")

    return livros


def listar_livros_por_autor(session, nome_autor):
    stmt = select(Autor).where(Autor.nome.icontains(nome_autor))
    autor = session.scalars(stmt).first()

    if autor:
        for livro in autor.livros:
            status = "Disponível" if livro.disponivel else "Indisponível"
            print(f"Livro: {livro.titulo} | Status: {status}")
        return autor.livros

    print(f"Autor '{nome_autor}' não encontrado.")
    return []